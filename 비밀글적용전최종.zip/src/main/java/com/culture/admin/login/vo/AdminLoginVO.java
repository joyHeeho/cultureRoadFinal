package com.culture.admin.login.vo;

import lombok.Data;

@Data
public class AdminLoginVO {
	private int managerNo;
	private String managerId;
	private String managerPw;
	private String managerEmail;
	private String managerPhone;
	private String managerDate;
}
