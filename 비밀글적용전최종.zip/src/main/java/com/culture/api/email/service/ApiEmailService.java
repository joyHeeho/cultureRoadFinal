package com.culture.api.email.service;

public interface ApiEmailService {
	public String generateRandomString(String userEmail);
}
