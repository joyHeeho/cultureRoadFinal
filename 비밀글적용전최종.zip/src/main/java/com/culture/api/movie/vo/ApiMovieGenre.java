package com.culture.api.movie.vo;

import lombok.Data;

@Data
public class ApiMovieGenre {
	private int id;
    private String name;
}