package com.culture.user.movie.list.vo;

import lombok.Data;

@Data
public class Genre {
    private int id;
    private String name;

}
